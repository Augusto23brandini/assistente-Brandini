"""
Módulo principal do assistente de voz
Integra todos os componentes e implementa a interface web
"""

from flask import Flask, render_template, request, jsonify, send_from_directory
import os
import sys
import threading
import time
import json
import base64
import tempfile
import logging
from datetime import datetime

# Adicionar diretório atual ao path para importar módulos
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Importar módulos do projeto
from modules.wake_word import WakeWordDetector
from modules.speech_recognition import WhisperRecognizer
from modules.llm_manager import LLMManager
from modules.text_to_speech import TextToSpeech
from modules.ai_command_integration import process_ai_command

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Inicializar Flask
app = Flask(__name__, static_url_path='')

# Configurações
CONFIG = {
    "wake_word": {
        "enabled": True,
        "model_name": "ei brandini",
        "threshold": 0.5
    },
    "speech_recognition": {
        "model_size": "base",
        "language": "pt"
    },
    "llm": {
        "use_openai": True,
        "openai_api_key": os.environ.get("OPENAI_API_KEY"),
        "local_model": "gpt2",
        "system_prompt": "Você é o Assistente Brandini, útil, conciso e amigável."
    },
    "tts": {
        "use_offline": True,
        "language": "pt-br",
        "rate": 180
    }
}

# Variáveis globais
wake_word_detector = None
speech_recognizer = None
llm_manager = None
tts_engine = None
background_thread = None
running = False

def initialize_components():
    """Inicializa todos os componentes do assistente"""
    global wake_word_detector, speech_recognizer, llm_manager, tts_engine
    
    logger.info("Inicializando componentes do assistente...")
    
    # Inicializar detector de palavra de ativação
    if CONFIG["wake_word"]["enabled"]:
        wake_word_detector = WakeWordDetector(
            model_name=CONFIG["wake_word"]["model_name"],
            threshold=CONFIG["wake_word"]["threshold"]
        )
    
    # Inicializar reconhecedor de fala
    speech_recognizer = WhisperRecognizer(
        model_size=CONFIG["speech_recognition"]["model_size"],
        language=CONFIG["speech_recognition"]["language"]
    )
    
    # Inicializar gerenciador de LLM
    llm_manager = LLMManager(
        openai_api_key=CONFIG["llm"]["openai_api_key"],
        local_model=CONFIG["llm"]["local_model"],
        system_prompt=CONFIG["llm"]["system_prompt"]
    )
    
    # Inicializar sintetizador de voz
    tts_engine = TextToSpeech(
        use_offline=CONFIG["tts"]["use_offline"],
        language=CONFIG["tts"]["language"],
        rate=CONFIG["tts"]["rate"]
    )
    
    logger.info("Componentes inicializados com sucesso")

def background_processing():
    """Função para processamento em segundo plano"""
    global running
    
    logger.info("Iniciando processamento em segundo plano")
    
    # Iniciar detector de palavra de ativação se habilitado
    if CONFIG["wake_word"]["enabled"] and wake_word_detector:
        wake_word_detector.start(callback=process_wake_word_detection)
    
    # Loop principal
    while running:
        # Verificar se há áudio para processar do detector de palavra de ativação
        if CONFIG["wake_word"]["enabled"] and wake_word_detector:
            audio_data = wake_word_detector.get_next_audio(timeout=0.1)
            if audio_data:
                process_audio(audio_data)
        
        # Pequena pausa para reduzir uso de CPU
        time.sleep(0.1)
    
    # Parar detector de palavra de ativação
    if CONFIG["wake_word"]["enabled"] and wake_word_detector:
        wake_word_detector.stop()
    
    logger.info("Processamento em segundo plano encerrado")

def process_wake_word_detection(audio_data):
    """Callback para quando a palavra de ativação é detectada"""
    logger.info("Palavra de ativação 'Ei Brandini' detectada!")
    
    # O áudio já é capturado pelo detector, não é necessário fazer nada aqui
    # O processamento será feito no loop principal

def process_audio(audio_data):
    """Processa áudio capturado após detecção da palavra de ativação"""
    logger.info("Processando áudio capturado...")
    
    try:
        # Reconhecer fala
        text = speech_recognizer.transcribe(audio_data)
        
        if not text:
            logger.warning("Não foi possível reconhecer fala no áudio")
            return
        
        logger.info(f"Texto reconhecido: {text}")
        
        # Processar comando usando o processador especializado ou LLM
        response = process_ai_command(text, llm_manager)
        
        logger.info(f"Resposta gerada ({response['source']}): {response['text']}")
        
        # Sintetizar fala
        audio_file = tts_engine.speak(response["text"], save_to_file=True, play_sound=False)
        
        logger.info(f"Resposta sintetizada: {audio_file}")
        
        # Armazenar resultado para acesso via API
        store_interaction_result(text, response["text"], audio_file, response["source"])
        
    except Exception as e:
        logger.error(f"Erro ao processar áudio: {e}")

# Armazenamento temporário para interações recentes
recent_interactions = []
MAX_RECENT_INTERACTIONS = 10

def store_interaction_result(input_text, response_text, audio_file, source):
    """Armazena resultado de interação para acesso via API"""
    global recent_interactions
    
    # Criar registro da interação
    interaction = {
        "timestamp": datetime.now().isoformat(),
        "input": input_text,
        "response": response_text,
        "audio_file": os.path.basename(audio_file) if audio_file else None,
        "source": source
    }
    
    # Adicionar ao início da lista
    recent_interactions.insert(0, interaction)
    
    # Limitar tamanho da lista
    if len(recent_interactions) > MAX_RECENT_INTERACTIONS:
        recent_interactions = recent_interactions[:MAX_RECENT_INTERACTIONS]

# Rotas Flask

@app.route('/')
def index():
    """Rota principal que renderiza a interface web"""
    return render_template('index.html')

@app.route('/manifest.json')
def manifest():
    """Rota para o manifesto PWA"""
    return app.send_static_file('manifest.json')

@app.route('/service-worker.js')
def service_worker():
    """Rota para o service worker"""
    return app.send_static_file('js/service-worker.js')

@app.route('/api/process-audio', methods=['POST'])
def api_process_audio():
    """API para processar áudio enviado pelo cliente"""
    if 'audio' not in request.files:
        return jsonify({'error': 'Nenhum arquivo de áudio enviado'}), 400
    
    audio_file = request.files['audio']
    
    # Salvar arquivo temporariamente
    temp_dir = tempfile.gettempdir()
    temp_path = os.path.join(temp_dir, f"input_{int(time.time())}.wav")
    audio_file.save(temp_path)
    
    try:
        # Reconhecer fala
        text = speech_recognizer.transcribe(temp_path)
        
        if not text:
            return jsonify({
                'status': 'error',
                'message': 'Não foi possível reconhecer a fala no áudio'
            }), 400
        
        # Processar comando usando o processador especializado ou LLM
        response = process_ai_command(text, llm_manager)
        
        # Sintetizar fala
        audio_path = tts_engine.speak(response["text"], save_to_file=True, play_sound=False)
        
        # Verificar se o arquivo de áudio foi criado
        if not audio_path or not os.path.exists(audio_path):
            logger.error(f"Arquivo de áudio não foi criado ou não existe: {audio_path}")
            return jsonify({
                'status': 'error',
                'message': 'Erro ao gerar áudio de resposta'
            }), 500
        
        # Ler arquivo de áudio e converter para base64
        try:
            with open(audio_path, 'rb') as audio_file:
                audio_data = base64.b64encode(audio_file.read()).decode('utf-8')
        except Exception as e:
            logger.error(f"Erro ao ler arquivo de áudio: {e}")
            return jsonify({
                'status': 'error',
                'message': f'Erro ao ler arquivo de áudio: {str(e)}'
            }), 500
        
        # Armazenar interação
        store_interaction_result(text, response["text"], audio_path, response["source"])
        
        return jsonify({
            'status': 'success',
            'text': text,
            'response': response["text"],
            'audio': audio_data,
            'source': response["source"]
        })
        
    except Exception as e:
        logger.error(f"Erro ao processar áudio: {e}")
        return jsonify({
            'status': 'error',
            'message': f'Erro ao processar áudio: {str(e)}'
        }), 500
    finally:
        # Limpar arquivo temporário
        if os.path.exists(temp_path):
            os.remove(temp_path)

@app.route('/api/process-text', methods=['POST'])
def api_process_text():
    """API para processar texto enviado pelo cliente"""
    data = request.json
    if not data or 'text' not in data:
        return jsonify({'error': 'Nenhum texto enviado'}), 400
    
    text = data['text']
    
    try:
        # Processar comando usando o processador especializado ou LLM
        response = process_ai_command(text, llm_manager)
        
        # Sintetizar fala
        audio_path = tts_engine.speak(response["text"], save_to_file=True, play_sound=False)
        
        # Verificar se o arquivo de áudio foi criado
        if not audio_path or not os.path.exists(audio_path):
            logger.error(f"Arquivo de áudio não foi criado ou não existe: {audio_path}")
            return jsonify({
                'status': 'error',
                'message': 'Erro ao gerar áudio de resposta'
            }), 500
        
        # Ler arquivo de áudio e converter para base64
        try:
            with open(audio_path, 'rb') as audio_file:
                audio_data = base64.b64encode(audio_file.read()).decode('utf-8')
        except Exception as e:
            logger.error(f"Erro ao ler arquivo de áudio: {e}")
            return jsonify({
                'status': 'error',
                'message': f'Erro ao ler arquivo de áudio: {str(e)}'
            }), 500
        
        # Armazenar interação
        store_interaction_result(text, response["text"], audio_path, response["source"])
        
        return jsonify({
            'status': 'success',
            'response': response["text"],
            'audio': audio_data,
            'source': response["source"]
        })
        
    except Exception as e:
        logger.error(f"Erro ao processar texto: {e}")
        return jsonify({
            'status': 'error',
            'message': f'Erro ao processar texto: {str(e)}'
        }), 500

@app.route('/api/toggle-backend', methods=['POST'])
def api_toggle_backend():
    """API para alternar entre OpenAI e modelo local"""
    backend = llm_manager.toggle_backend()
    return jsonify({
        'status': 'success',
        'backend': backend
    })

@app.route('/api/recent-interactions', methods=['GET'])
def api_recent_interactions():
    """API para obter interações recentes"""
    return jsonify({
        'status': 'success',
        'interactions': recent_interactions
    })

@app.route('/api/config', methods=['GET', 'POST'])
def api_config():
    """API para obter ou atualizar configuração"""
    global CONFIG
    
    if request.method == 'GET':
        # Remover chave da API por segurança
        safe_config = CONFIG.copy()
        if 'llm' in safe_config and 'openai_api_key' in safe_config['llm']:
            safe_config['llm']['openai_api_key'] = '***' if safe_config['llm']['openai_api_key'] else None
        
        return jsonify({
            'status': 'success',
            'config': safe_config
        })
    
    # Atualizar configuração
    data = request.json
    if not data:
        return jsonify({'error': 'Nenhuma configuração enviada'}), 400
    
    # Função recursiva para atualizar configuração
    def update_dict(d, u):
        for k, v in u.items():
            if isinstance(v, dict) and k in d and isinstance(d[k], dict):
                update_dict(d[k], v)
            else:
                d[k] = v
    
    # Fazer cópia da configuração atual
    old_config = json.dumps(CONFIG)
    
    # Atualizar configuração
    update_dict(CONFIG, data)
    
    # Verificar se é necessário reinicializar componentes
    if old_config != json.dumps(CONFIG):
        # Parar processamento em segundo plano
        stop_background_processing()
        
        # Reinicializar componentes
        initialize_components()
        
        # Reiniciar processamento em segundo plano
        start_background_processing()
    
    return jsonify({
        'status': 'success',
        'message': 'Configuração atualizada com sucesso',
        'config': CONFIG
    })

@app.route('/audio/<filename>')
def serve_audio(filename):
    """Rota para servir arquivos de áudio gerados"""
    if tts_engine:
        return send_from_directory(tts_engine.output_dir, filename)
    return '', 404

def start_background_processing():
    """Inicia processamento em segundo plano"""
    global background_thread, running
    
    if background_thread and background_thread.is_alive():
        logger.warning("Processamento em segundo plano já está em execução")
        return
    
    running = True
    background_thread = threading.Thread(target=background_processing)
    background_thread.daemon = True
    background_thread.start()
    
    logger.info("Processamento em segundo plano iniciado")

def stop_background_processing():
    """Para processamento em segundo plano"""
    global running, background_thread
    
    if not background_thread or not background_thread.is_alive():
        logger.warning("Processamento em segundo plano não está em execução")
        return
    
    logger.info("Parando processamento em segundo plano...")
    running = False
    background_thread.join(timeout=5.0)
    
    if background_thread.is_alive():
        logger.warning("Não foi possível parar o thread em segundo plano")
    else:
        logger.info("Processamento em segundo plano parado com sucesso")
        background_thread = None

def start_server(host='0.0.0.0', port=5000, debug=False):
    """Inicia o servidor Flask"""
    try:
        # Criar diretório de áudio se não existir
        audio_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "audio_output")
        os.makedirs(audio_dir, exist_ok=True)
        logger.info(f"Diretório de áudio verificado: {audio_dir}")
        
        # Inicializar componentes
        initialize_components()
        
        # Iniciar processamento em segundo plano
        start_background_processing()
        
        # Iniciar servidor Flask
        app.run(host=host, port=port, debug=debug, use_reloader=False)
    finally:
        # Garantir que o processamento em segundo plano seja encerrado
        stop_background_processing()

if __name__ == '__main__':
    start_server(debug=True)

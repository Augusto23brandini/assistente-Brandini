"""
Script de teste para verificar a integração dos comandos no Assistente Brandini
"""

import sys
import os

# Adicionar diretório atual ao path para importar módulos
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Importar módulos do projeto
from modules.command_integration import process_command

def test_commands():
    """Testa vários comandos para verificar a integração"""
    
    # Lista de comandos para testar
    test_commands = [
        # Comandos gerais
        "Brandini, que horas são?",
        "Brandini, que dia é hoje?",
        "Brandini, conte uma piada",
        "Brandini, qual a previsão do tempo para hoje?",
        "Brandini, quanto é 15% de 200?",
        "Brandini, o que você pode fazer?",
        
        # Comandos de produtividade
        "Brandini, defina um alarme para 8h da manhã",
        "Brandini, crie um lembrete para comprar leite às 18h",
        "Brandini, adicione pão à minha lista de compras",
        "Brandini, mostre minha lista de compras",
        "Brandini, o que eu tenho na minha agenda hoje?",
        
        # Comandos de comunicação
        "Brandini, ligue para Maria",
        "Brandini, mande uma mensagem para João dizendo que vou me atrasar",
        "Brandini, leia minhas mensagens",
        
        # Comandos de música e mídia
        "Brandini, toque música relaxante",
        "Brandini, aumente o volume",
        "Brandini, próxima música",
        "Brandini, que música está tocando?",
        
        # Comandos de casa inteligente
        "Brandini, acenda a luz da sala",
        "Brandini, ajuste o termostato para 22 graus",
        "Brandini, ligue a cafeteira",
        
        # Comandos de dispositivo
        "Brandini, aumente o brilho da tela",
        "Brandini, ative o Wi-Fi",
        "Brandini, abra o aplicativo Calendário",
        "Brandini, tire uma foto",
        
        # Comandos de IA e conhecimento
        "Brandini, o que é a Alexa?",
        "Brandini, fale sobre o ChatGPT",
        "Brandini, compare Siri, Alexa e Google Assistente",
        "Brandini, quais são os melhores LLMs de código aberto?",
        
        # Comandos não reconhecidos para testar fallback
        "Brandini, qual é o sentido da vida?",
        "Brandini, você gosta de pizza?",
        "Brandini, conte-me sobre sua criação"
    ]
    
    # Testar cada comando
    print("=== TESTE DE INTEGRAÇÃO DE COMANDOS ===\n")
    
    for i, cmd in enumerate(test_commands, 1):
        print(f"Teste #{i}: \"{cmd}\"")
        
        try:
            # Processar comando
            response = process_command(cmd)
            
            # Exibir resultado
            print(f"  Processado por: {response['processed_by']}")
            print(f"  Fonte: {response['source']}")
            print(f"  Resposta: {response['text'][:100]}..." if len(response['text']) > 100 else f"  Resposta: {response['text']}")
            print(f"  Status: SUCESSO")
        except Exception as e:
            print(f"  Status: FALHA - {str(e)}")
        
        print("-" * 50)
    
    print("\n=== TESTE CONCLUÍDO ===")

if __name__ == "__main__":
    test_commands()

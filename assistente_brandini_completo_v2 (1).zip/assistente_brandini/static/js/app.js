/**
 * Aplicativo principal do Assistente de Voz
 * Gerencia a interface do usuário e a comunicação com o backend
 */

// Elementos da interface
const chatContainer = document.getElementById('chatContainer');
const textInput = document.getElementById('textInput');
const sendButton = document.getElementById('sendButton');
const recordButton = document.getElementById('recordButton');
const recordButtonText = document.getElementById('recordButtonText');
const toggleBackendButton = document.getElementById('toggleBackendButton');
const statusDot = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');
const connectionStatus = document.getElementById('connectionStatus');
const backendType = document.getElementById('backendType');
const settingsToggle = document.getElementById('settingsToggle');
const settingsPanel = document.getElementById('settingsPanel');
const saveSettingsButton = document.getElementById('saveSettingsButton');

// Configurações
let config = {
    wake_word: {
        enabled: true,
        model_name: "hey jarvis",
        threshold: 0.5
    },
    speech_recognition: {
        model_size: "base",
        language: "pt"
    },
    llm: {
        use_openai: true,
        local_model: "gpt2"
    },
    tts: {
        use_offline: true,
        language: "pt-br",
        rate: 180
    }
};

// Estado da aplicação
let isRecording = false;
let mediaRecorder = null;
let audioChunks = [];
let isOnline = navigator.onLine;

// Verificar status de conexão
window.addEventListener('online', () => {
    isOnline = true;
    updateConnectionStatus();
});

window.addEventListener('offline', () => {
    isOnline = false;
    updateConnectionStatus();
});

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
    // Carregar configurações do servidor
    fetchConfig();
    
    // Configurar event listeners
    setupEventListeners();
    
    // Verificar status de conexão
    updateConnectionStatus();
    
    // Adicionar mensagem de boas-vindas
    addMessage('Olá! Sou seu assistente de voz. Como posso ajudar?', 'assistant');
});

/**
 * Configura os event listeners para os elementos da interface
 */
function setupEventListeners() {
    // Enviar mensagem ao pressionar Enter no campo de texto
    textInput.addEventListener('keypress', (event) => {
        if (event.key === 'Enter') {
            sendTextMessage();
        }
    });
    
    // Botão de enviar mensagem
    sendButton.addEventListener('click', sendTextMessage);
    
    // Botão de gravação
    recordButton.addEventListener('click', toggleRecording);
    
    // Botão de alternar backend
    toggleBackendButton.addEventListener('click', toggleBackend);
    
    // Toggle de configurações
    settingsToggle.addEventListener('click', toggleSettings);
    
    // Botão de salvar configurações
    saveSettingsButton.addEventListener('click', saveSettings);
}

/**
 * Busca as configurações atuais do servidor
 */
function fetchConfig() {
    fetch('/api/config')
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                config = data.config;
                updateSettingsUI();
                updateBackendType();
            }
        })
        .catch(error => {
            console.error('Erro ao carregar configurações:', error);
            setStatus('error', 'Erro ao carregar configurações');
        });
}

/**
 * Atualiza a interface com as configurações atuais
 */
function updateSettingsUI() {
    // Wake word
    document.getElementById('wakeWordEnabled').checked = config.wake_word.enabled;
    document.getElementById('wakeWordModel').value = config.wake_word.model_name;
    
    // LLM
    document.getElementById('llmType').value = config.llm.use_openai ? 'openai' : 'local';
    
    // TTS
    document.getElementById('ttsOffline').checked = config.tts.use_offline;
    document.getElementById('ttsLanguage').value = config.tts.language;
}

/**
 * Salva as configurações no servidor
 */
function saveSettings() {
    // Obter valores da interface
    const newConfig = {
        wake_word: {
            enabled: document.getElementById('wakeWordEnabled').checked,
            model_name: document.getElementById('wakeWordModel').value
        },
        llm: {
            use_openai: document.getElementById('llmType').value === 'openai'
        },
        tts: {
            use_offline: document.getElementById('ttsOffline').checked,
            language: document.getElementById('ttsLanguage').value
        }
    };
    
    // Enviar para o servidor
    fetch('/api/config', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(newConfig)
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            config = data.config;
            setStatus('success', 'Configurações salvas');
            toggleSettings();
            updateBackendType();
        } else {
            setStatus('error', 'Erro ao salvar configurações');
        }
    })
    .catch(error => {
        console.error('Erro ao salvar configurações:', error);
        setStatus('error', 'Erro ao salvar configurações');
    });
}

/**
 * Alterna a exibição do painel de configurações
 */
function toggleSettings() {
    settingsPanel.classList.toggle('active');
    const isActive = settingsPanel.classList.contains('active');
    settingsToggle.querySelector('.toggle-icon').textContent = isActive ? '▲' : '▼';
}

/**
 * Envia uma mensagem de texto para o servidor
 */
function sendTextMessage() {
    const text = textInput.value.trim();
    if (!text) return;
    
    // Adicionar mensagem ao chat
    addMessage(text, 'user');
    
    // Limpar campo de texto
    textInput.value = '';
    
    // Atualizar status
    setStatus('processing', 'Processando...');
    
    // Enviar para o servidor
    fetch('/api/process-text', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ text })
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            // Adicionar resposta ao chat
            addMessage(data.response, 'assistant');
            
            // Reproduzir áudio
            playAudio(data.audio);
            
            // Atualizar status
            setStatus('ready', 'Pronto');
            
            // Atualizar tipo de backend
            if (data.source) {
                updateBackendType(data.source);
            }
        } else {
            setStatus('error', 'Erro: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Erro ao processar texto:', error);
        setStatus('error', 'Erro ao processar texto');
    });
}

/**
 * Alterna entre iniciar e parar a gravação de áudio
 */
function toggleRecording() {
    if (isRecording) {
        stopRecording();
    } else {
        startRecording();
    }
}

/**
 * Inicia a gravação de áudio
 */
function startRecording() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setStatus('error', 'Seu navegador não suporta gravação de áudio');
        return;
    }
    
    navigator.mediaDevices.getUserMedia({ audio: true })
        .then(stream => {
            mediaRecorder = new MediaRecorder(stream);
            audioChunks = [];
            
            mediaRecorder.ondataavailable = event => {
                audioChunks.push(event.data);
            };
            
            mediaRecorder.onstop = () => {
                const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
                sendAudioToServer(audioBlob);
            };
            
            mediaRecorder.start();
            isRecording = true;
            
            // Atualizar interface
            recordButton.classList.add('recording');
            recordButtonText.textContent = 'Parar Gravação';
            setStatus('listening', 'Gravando áudio...');
        })
        .catch(error => {
            console.error('Erro ao acessar microfone:', error);
            setStatus('error', 'Erro ao acessar microfone');
        });
}

/**
 * Para a gravação de áudio
 */
function stopRecording() {
    if (mediaRecorder && isRecording) {
        mediaRecorder.stop();
        isRecording = false;
        
        // Atualizar interface
        recordButton.classList.remove('recording');
        recordButtonText.textContent = 'Iniciar Gravação';
        setStatus('processing', 'Processando áudio...');
        
        // Parar todas as faixas do stream
        mediaRecorder.stream.getTracks().forEach(track => track.stop());
    }
}

/**
 * Envia o áudio gravado para o servidor
 * @param {Blob} audioBlob - Blob contendo o áudio gravado
 */
function sendAudioToServer(audioBlob) {
    const formData = new FormData();
    formData.append('audio', audioBlob, 'recording.wav');
    
    fetch('/api/process-audio', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            // Adicionar texto reconhecido ao chat
            addMessage(data.text, 'user');
            
            // Adicionar resposta ao chat
            addMessage(data.response, 'assistant');
            
            // Reproduzir áudio
            playAudio(data.audio);
            
            // Atualizar status
            setStatus('ready', 'Pronto');
            
            // Atualizar tipo de backend
            if (data.source) {
                updateBackendType(data.source);
            }
        } else {
            setStatus('error', 'Erro: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Erro ao processar áudio:', error);
        setStatus('error', 'Erro ao processar áudio');
    });
}

/**
 * Reproduz o áudio recebido do servidor
 * @param {string} base64Audio - Áudio em formato base64
 */
function playAudio(base64Audio) {
    if (!base64Audio) return;
    
    const audio = new Audio(`data:audio/mp3;base64,${base64Audio}`);
    audio.play();
}

/**
 * Alterna entre OpenAI e modelo local
 */
function toggleBackend() {
    fetch('/api/toggle-backend', {
        method: 'POST'
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            updateBackendType(data.backend);
            setStatus('success', `Backend alternado para ${data.backend}`);
        } else {
            setStatus('error', 'Erro ao alternar backend');
        }
    })
    .catch(error => {
        console.error('Erro ao alternar backend:', error);
        setStatus('error', 'Erro ao alternar backend');
    });
}

/**
 * Atualiza o tipo de backend exibido na interface
 * @param {string} type - Tipo de backend (openai, local, etc.)
 */
function updateBackendType(type) {
    if (type) {
        backendType.textContent = type;
    } else {
        backendType.textContent = config.llm.use_openai ? 'OpenAI' : 'Local';
    }
}

/**
 * Atualiza o status de conexão exibido na interface
 */
function updateConnectionStatus() {
    connectionStatus.textContent = isOnline ? 'Online' : 'Offline';
    
    if (!isOnline) {
        setStatus('offline', 'Offline');
    } else {
        setStatus('ready', 'Pronto');
    }
}

/**
 * Define o status atual do assistente
 * @param {string} state - Estado do assistente (ready, listening, processing, error, offline)
 * @param {string} message - Mensagem de status
 */
function setStatus(state, message) {
    statusText.textContent = message;
    
    // Remover classes anteriores
    statusDot.classList.remove('listening', 'processing', 'offline');
    
    // Adicionar classe apropriada
    if (state === 'listening') {
        statusDot.classList.add('listening');
    } else if (state === 'processing') {
        statusDot.classList.add('processing');
    } else if (state === 'offline' || state === 'error') {
        statusDot.classList.add('offline');
    }
}

/**
 * Adiciona uma mensagem ao container de chat
 * @param {string} text - Texto da mensagem
 * @param {string} role - Papel do remetente (user, assistant, system)
 */
function addMessage(text, role) {
    const messageElement = document.createElement('div');
    messageElement.classList.add('message');
    messageElement.classList.add(`${role}-message`);
    messageElement.textContent = text;
    
    chatContainer.appendChild(messageElement);
    
    // Rolar para a mensagem mais recente
    chatContainer.scrollTop = chatContainer.scrollHeight;
}
